package ru.swordreach.indicator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public final class SwordReachIndicator implements ClientModInitializer {
    private static final double SWORD_REACH = 3.0;
    private static final double RING_RADIUS = 0.62;
    private static final int SEGMENTS = 64;

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            if (!(mc.hitResult instanceof EntityHitResult entityHit)) return;
            if (!(mc.player.getMainHandItem().is(ItemTags.SWORDS))) return;

            Entity target = entityHit.getEntity();
            AABB box = target.getBoundingBox();
            Vec3 eye = mc.player.getEyePosition();
            boolean inReach = box.distanceToSqr(eye) <= SWORD_REACH * SWORD_REACH;

            Vec3 camera = mc.gameRenderer.getMainCamera().position();
            PoseStack matrices = context.matrices();
            matrices.pushPose();
            matrices.translate(target.getX() - camera.x,
                    box.minY - camera.y + 0.025,
                    target.getZ() - camera.z);

            VertexConsumer lines = context.consumers().getBuffer(RenderTypes.lines());
            PoseStack.Pose pose = matrices.last();
            float red = inReach ? 0.05f : 1.0f;
            float green = inReach ? 1.0f : 0.05f;
            float blue = 0.05f;

            for (int i = 0; i < SEGMENTS; i++) {
                double a1 = Math.PI * 2.0 * i / SEGMENTS;
                double a2 = Math.PI * 2.0 * (i + 1) / SEGMENTS;
                float x1 = (float) (Math.cos(a1) * RING_RADIUS);
                float z1 = (float) (Math.sin(a1) * RING_RADIUS);
                float x2 = (float) (Math.cos(a2) * RING_RADIUS);
                float z2 = (float) (Math.sin(a2) * RING_RADIUS);

                lines.addVertex(pose, x1, 0.0f, z1)
                        .setColor(red, green, blue, 0.95f)
                        .setNormal(pose, 0.0f, 1.0f, 0.0f)
                        .setLineWidth(4.0f);
                lines.addVertex(pose, x2, 0.0f, z2)
                        .setColor(red, green, blue, 0.95f)
                        .setNormal(pose, 0.0f, 1.0f, 0.0f)
                        .setLineWidth(4.0f);
            }
            matrices.popPose();
        });
    }
}
